package org.andengine.extension.multiplayer.protocol.adt.message.client;

import org.andengine.extension.multiplayer.protocol.adt.message.IMessage;

/**
 * (c) 2010 Nicolas Gramlich
 * (c) 2011 Zynga Inc.
 *
 * @author Nicolas Gramlich
 * @since 18:30:28 - 19.09.2009
 */
public interface IClientMessage extends IMessage {
	// ===========================================================
	// Final Fields
	// ===========================================================

	// ===========================================================
	// Methods
	// ===========================================================
}
